Занятие 1 (Редакс круговорот, useDispatch, useSelector):
* полезные ссылки по занятию находятся в файле lesson1.ts 
Разбираемся с основами редакса на базе простого конвертора валют.
Что нужно сделать:
1) Ознакомиться с файлами проекта (папки Redux, containers, components и файл App.tsx) 
и понять их логику;
2) Заполнить экшены и экшенкриэйторы в файле action.ts;
3) Заполнить редюссер в файле currencyReducer;
4) Все приложение должно работать без вставок // @ts-ignore;
5) Переписать компоненту CurrencyExchangeContainer c помощью сокращенной записи mapDispatchToProps;
6) Переписать компоненту CurrencyExchangeContainer с помощью useDispatch и useSelector.